/*================================
Preloader
===============================*/

$(window).on('load', function (){ //make sure whole site is loaded
    $('#status').fadeOut();
    $('#preloader').delay(350).fadeOut();
});
